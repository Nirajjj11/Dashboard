import React from 'react'
import 'bootstrap/dist/css/bootstrap.min.css'

import NoOfEmployee from '../Components/NoOfEmployee'
import Present from '../Components/Present'
import DeptWise from '../Components/DeptWise'
import DateTimeDisplay from '../Components/Date'

function Dashboard() {
  return (
    <div className="container-fluid p-4 bg-light min-vh-100">

      {/* Header */}
      <div className="mb-4">
        <h2 className="fw-bold">Employee Dashboard</h2>
        <p className="text-muted">Overview of workforce analytics</p>
      </div>

      {/* TOP ROW → Key Metrics */}
      <div className="row g-4 mb-4">

        <div className="col-lg-4 col-md-6">
          <div className="card shadow-sm border-0 rounded-4 h-100">
            <div className="card-body">
              <NoOfEmployee />
            </div>
          </div>
        </div>

        <div className="col-lg-4 col-md-6">
          <div className="card shadow-sm border-0 rounded-4 h-100">
            <div className="card-body">
              <Present />
            </div>
          </div>
        </div>

        <div className="col-lg-4 col-md-12">
          <div className="card shadow-sm border-0 rounded-4 h-100 text-center">
            <div className="card-body d-flex flex-column justify-content-center">
              <DateTimeDisplay />
            </div>
          </div>
        </div>

      </div>

      {/* SECOND ROW → Detailed Analytics */}
      <div className="row g-4">

        <div className="col-12">
          <div className="card shadow-sm border-0 rounded-4">
            <div className="card-body">
              <DeptWise />
            </div>
          </div>
        </div>

      </div>

    </div>
  )
}

export default Dashboard