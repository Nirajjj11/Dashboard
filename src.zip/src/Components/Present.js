import axios from 'axios'
import React, { useEffect, useState } from 'react'
import 'bootstrap/dist/css/bootstrap.min.css'

function Present() {

    const apiUrl = "http://localhost:3001/employees"
    const [presentHours, setPresentHours] = useState(0)
    const [holidays, setHolidays] = useState(0)

    useEffect(() => {
        const fetchEmp = async () => {
            try {
                const response = await axios.get(apiUrl)
                const employees = response.data || []

                if (employees.length === 0) {
                    setPresentHours(0)
                    setHolidays(0)
                    return
                }

                // SAFE SUM
                const totalDays = employees.reduce((sum, emp) => {
                    const days = Number(emp.daysPresent)
                    return sum + (isNaN(days) ? 0 : days)
                }, 0)

                const totalHours = totalDays * 8
                setPresentHours(totalHours)

                const avgDaysWorked = totalDays / employees.length
                const totalDaysInYear = 365

                const holidayCalc = totalDaysInYear - avgDaysWorked

                setHolidays(
                    isNaN(holidayCalc) || !isFinite(holidayCalc)
                        ? 0
                        : holidayCalc
                )

            } catch (error) {
                console.error("Error fetching Employees:", error)
            }
        }

        fetchEmp()
    }, [])

    return (
        <div className="container mt-5">
            <div className="row g-4">

                <div className="col-md-6">
                    <div className="card shadow-lg border-0 rounded-4 text-center">
                        <div className="card-body">
                            <h5 className="text-muted">Total Work Hours</h5>
                            <h1 className="display-4 fw-bold text-primary">
                                {presentHours}
                            </h1>
                        </div>
                    </div>
                </div>

                <div className="col-md-6">
                    <div className="card shadow-lg border-0 rounded-4 text-center">
                        <div className="card-body">
                            <h5 className="text-muted">Avg Holidays</h5>
                            <h1 className="display-4 fw-bold text-danger">
                                {Math.round(holidays)}
                            </h1>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    )
}

export default Present