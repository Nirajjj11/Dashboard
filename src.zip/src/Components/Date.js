import React, { useState, useEffect } from 'react'
import 'bootstrap/dist/css/bootstrap.min.css'

const DateTimeDisplay = () => {
    const [currentDateTime, setCurrentDateTime] = useState(new Date())

    useEffect(() => {
        const timer = setInterval(() => {
            setCurrentDateTime(new Date())
        }, 1000)

        return () => clearInterval(timer)
    }, [])

    const formatDate = (date) => {
        return new Intl.DateTimeFormat('en-GB', {
            day: '2-digit',
            month: 'long',
            year: 'numeric',
        }).format(date)
    }

    return (
        <div className="container mt-4">
            <div className="card shadow-lg border-0 rounded-4 text-center p-4">

                <h5 className="text-muted mb-3">Current Date & Time</h5>

                {/* Time */}
                <h1 className="display-3 fw-bold text-primary">
                    {currentDateTime.toLocaleTimeString()}
                </h1>

                {/* Date */}
                <h4 className="mt-3 text-secondary">
                    {formatDate(currentDateTime)}
                </h4>

            </div>
        </div>
    )
}

export default DateTimeDisplay