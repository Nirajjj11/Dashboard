import React, { useEffect, useState } from 'react'
import 'bootstrap/dist/css/bootstrap.min.css'

const EmployeeJobRoles = () => {
    const [jobRoleCounts, setJobRoleCounts] = useState({})
    const [loading, setLoading] = useState(true)

    useEffect(() => {
        fetch('http://localhost:3001/employees')
            .then((res) => res.json())
            .then((data) => {

                const counts = data.reduce((acc, emp) => {
                    const role = (emp.jobRole || 'unknown').toLowerCase()
                    acc[role] = (acc[role] || 0) + 1
                    return acc
                }, {})

                setJobRoleCounts(counts)
                setLoading(false)
            })
            .catch((err) => {
                console.error('Error:', err)
                setLoading(false)
            })
    }, [])

    if (loading) {
        return (
            <div className="text-center mt-5">
                <div className="spinner-border text-primary"></div>
            </div>
        )
    }

    return (
        <div className="container mt-5">
            <h4 className="mb-4 text-center text-muted">
                Employee Role Distribution
            </h4>

            <div className="row g-4">
                {Object.entries(jobRoleCounts).map(([role, count]) => (
                    <div className="col-md-4 col-sm-6" key={role}>
                        <div className="card shadow-lg border-0 rounded-4 text-center p-4">

                            {/* Role Name */}
                            <h5 className="text-muted">
                                {role.charAt(0).toUpperCase() + role.slice(1)}
                            </h5>

                            {/* Count */}
                            <h1 className="display-5 fw-bold text-primary">
                                {count}
                            </h1>

                        </div>
                    </div>
                ))}
            </div>
        </div>
    )
}

export default EmployeeJobRoles