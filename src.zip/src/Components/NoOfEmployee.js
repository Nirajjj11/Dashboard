import axios from 'axios'
import React, { useEffect, useState } from 'react'
import 'bootstrap/dist/css/bootstrap.min.css'

function NoOfEmployee() {
    const [employees, setEmployees] = useState([])
    const apiUrl = "http://localhost:3001/employees"

    useEffect(() => {
        const fetchEmp = async () => {
            try {
                const response = await axios.get(apiUrl);
                setEmployees(response.data)
            } catch (error) {
                console.error("Error fetching Employees:", error)
            }
        };
        fetchEmp();
    }, [])

    // function to check if employee is new (<6 months)
    function isNewEmployee(joiningDate) {
        const currentDate = new Date()
        const joinDate = new Date(joiningDate)

        const monthDiff =
            (currentDate.getFullYear() - joinDate.getFullYear()) * 12 +
            (currentDate.getMonth() - joinDate.getMonth())

        return monthDiff < 6
    }

    const totalEmployees = employees.length
    const newEmployees = employees.filter(emp =>
        isNewEmployee(emp.joiningDate)
    ).length

    return (
        <div className="container mt-5">
            <div className="row g-4">

                {/* Total Employees Card */}
                <div className="col-md-6">
                    <div className="card shadow-lg border-0 rounded-4">
                        <div className="card-body text-center">
                            <h5 className="card-title text-muted">Total Employees</h5>
                            <h1 className="display-4 fw-bold text-primary">
                                {totalEmployees}
                            </h1>
                        </div>
                    </div>
                </div>

                {/* New Employees Card */}
                <div className="col-md-6">
                    <div className="card shadow-lg border-0 rounded-4">
                        <div className="card-body text-center">
                            <h5 className="card-title text-muted">New Employees (Last 6 Months)</h5>
                            <h1 className="display-4 fw-bold text-success">
                                {newEmployees}
                            </h1>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    )
}

export default NoOfEmployee